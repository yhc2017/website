<?php
$conn=mysqli_connect("localhost","root","0718","news3") or die("connection error".mysql_error());
mysqli_query($conn,"set names utf8");
?>
